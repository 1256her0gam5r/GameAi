# GameAI
Open this folder in Android Studio (Koala or newer), let Gradle sync (it creates the wrapper), then Run.
Enter your Gemini API key in the app's Settings. For a public release, use a backend proxy instead of user-entered keys.
Notes: Auto Clicker taps screen centre; Screen Help takes ONE screenshot (3s delay) kept only in memory.

Build online: push to GitHub, open Actions > Build APK, download the APK artifact.
Privacy policy page: docs/index.html (enable GitHub Pages: Settings > Pages > main /docs).
