package com.gameai

import android.annotation.SuppressLint
import android.media.*

/** Record once (kept in memory only), then replay with a preset voice - no overlay permission needed. */
object VoiceChanger {
    val presets = listOf(
        R.string.preset_girl to 1.25f, R.string.preset_boy to 0.85f,
        R.string.preset_cute_girl to 1.45f, R.string.preset_cute_boy to 1.15f)

    private const val RATE = 16000
    @Volatile private var last: ShortArray? = null
    @Volatile var lastFactor = 1.25f
    val hasRecording get() = last != null

    @SuppressLint("MissingPermission")
    fun record(seconds: Int, onDone: () -> Unit) {
        Thread {
            val total = RATE * seconds
            val buf = ShortArray(total)
            var n = 0
            try {
                val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
                try {
                    rec.startRecording()
                    while (n < total) {
                        val r = rec.read(buf, n, minOf(1024, total - n))
                        if (r <= 0) break
                        n += r
                    }
                } finally { rec.stop(); rec.release() }
                if (n > 0) last = buf.copyOf(n)
            } catch (e: Exception) { }
            onDone()
        }.start()
    }

    fun play(factor: Float): Boolean {
        val data = last ?: return false
        lastFactor = factor
        Thread {
            try {
                val outRate = (RATE * factor).toInt()
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(outRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(data.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                track.write(data, 0, data.size)
                track.play()
                Thread.sleep(data.size * 1000L / outRate + 200)
                track.release()
            } catch (e: Exception) { }
        }.start()
        return true
    }

    fun playLast() = play(lastFactor)
}
