package com.gameai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Settings stored privately on-device. The API key is entered by the user, never hard-coded. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("gameai", Context.MODE_PRIVATE)
    /** API key lives in EncryptedSharedPreferences (Android Keystore-backed). */
    private fun secure(c: Context): SharedPreferences = try {
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(c, "gameai_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    } catch (e: Exception) { c.getSharedPreferences("gameai_secure_fallback", Context.MODE_PRIVATE) }
    fun apiKey(c: Context) = secure(c).getString("key", "") ?: ""
    fun model(c: Context) = sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun lowEnd(c: Context) = sp(c).getBoolean("low", true)
    fun consent(c: Context) = sp(c).getBoolean("consent", false)
    fun setConsent(c: Context) = sp(c).edit().putBoolean("consent", true).apply()
    fun save(c: Context, key: String, model: String, low: Boolean) {
        secure(c).edit().putString("key", key.trim()).apply()
        sp(c).edit().putString("model", model.trim().ifEmpty { "gemini-2.5-flash" }).putBoolean("low", low).apply()
    }
}

/**
 * Calls the official Gemini REST API (generateContent) directly.
 * For a public release, route this through your own backend/proxy instead of shipping user keys.
 */
class GeminiManager(private val ctx: Context) {

    suspend fun ask(prompt: String, jpeg: ByteArray? = null): String = withContext(Dispatchers.IO) {
        val key = Prefs.apiKey(ctx)
        if (key.isEmpty()) return@withContext ctx.getString(R.string.need_key)
        try {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            if (jpeg != null) parts.put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", ctx.getString(R.string.sys_prompt)))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject()
                    .put("maxOutputTokens", if (Prefs.lowEnd(ctx)) 600 else 1200))

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Prefs.model(ctx)}:generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) return@withContext "Error $code: " +
                (runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrNull() ?: text.take(200))

            JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}
