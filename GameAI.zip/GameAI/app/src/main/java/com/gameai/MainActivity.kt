package com.gameai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val gemini by lazy { GeminiManager(this) }
    private val voice by lazy { VoiceCommandManager(this) }
    private val capture by lazy { ScreenCaptureManager(this) }
    private lateinit var input: EditText
    private lateinit var out: TextView
    private var capturePrompt = ""
    private var afterMic: (() -> Unit)? = null

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) afterMic?.invoke() else toast(R.string.mic_denied)
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { GameMode.on(this) }
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && text != null) onCommand(text)
    }
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            out.text = getString(R.string.capture_wait)
            capture.start(r.resultCode, data) { jpeg -> runOnUiThread { ask(capturePrompt, jpeg) } }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
            setPadding(32, 48, 32, 24)
            fitsSystemWindows = true
        }
        root.addView(TextView(this).apply {
            text = getString(R.string.title); textSize = 28f; setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
        })
        input = EditText(this).apply {
            hint = getString(R.string.hint); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(input)
        out = TextView(this).apply { setTextColor(Color.parseColor("#C9D1D9")); setPadding(0, 12, 0, 12) }
        val outScroll = ScrollView(this).apply { addView(out) }
        root.addView(outScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun btn(label: Int, action: () -> Unit) = menu.addView(Button(this).apply {
            text = getString(label); setOnClickListener { action() }
            setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1F6FEB"))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        btn(R.string.b_gemini) { ask(input.text.toString()) }
        btn(R.string.b_voice) { voiceChanger() }
        btn(R.string.b_clicker) { autoClicker() }
        btn(R.string.b_screen) { startCapture(getString(R.string.screen_prompt)) }
        btn(R.string.b_cmds) { withMic { speech.launch(voice.createVoiceIntent()) } }
        btn(R.string.b_avatar) { startCapture(getString(R.string.avatar_prompt)) }
        btn(R.string.b_mode) { toggleGameMode(true) }
        btn(R.string.b_settings) { settings() }
        root.addView(ScrollView(this).apply { addView(menu) }, LinearLayout.LayoutParams(-1, 0, 1.6f))
        setContentView(root)
        handleIntent(intent)
        if (!Prefs.consent(this)) showConsent()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i?.getStringExtra("action") == "stop_clicker") AutoClickAccessibilityService.instance?.stopClicking()
    }

    private fun ask(prompt: String, jpeg: ByteArray? = null) {
        if (prompt.isBlank()) return
        out.text = getString(R.string.thinking)
        lifecycleScope.launch { out.text = gemini.ask(prompt, jpeg) }
    }

    private fun toast(r: Int) = Toast.makeText(this, r, Toast.LENGTH_SHORT).show()

    private fun withMic(block: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) block()
        else { afterMic = block; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun voiceChanger() {
        out.text = getString(R.string.voice_tip)
        val names = VoiceChanger.presets.map { getString(it.first) } + getString(R.string.rec_new)
        AlertDialog.Builder(this).setTitle(R.string.b_voice).setItems(names.toTypedArray()) { _, i ->
            if (i == VoiceChanger.presets.size) recordVoice(null)
            else {
                val f = VoiceChanger.presets[i].second
                if (VoiceChanger.hasRecording) VoiceChanger.play(f) else recordVoice(f)
            }
        }.show()
    }

    private fun recordVoice(thenPlay: Float?) = withMic {
        toast(R.string.recording)
        VoiceChanger.record(6) { runOnUiThread { if (thenPlay != null) VoiceChanger.play(thenPlay) else voiceChanger() } }
    }

    private fun showConsent() {
        AlertDialog.Builder(this).setTitle(R.string.consent_title).setMessage(R.string.consent_body)
            .setCancelable(false)
            .setPositiveButton(R.string.accept) { _, _ -> Prefs.setConsent(this) }
            .setNeutralButton(R.string.privacy_policy) { _, _ -> showPolicy(true) }
            .setNegativeButton(R.string.exit) { _, _ -> finish() }.show()
    }

    private fun showPolicy(backToConsent: Boolean = false) {
        val t = resources.openRawResource(R.raw.privacy_policy).bufferedReader().use { it.readText() }.replace("## ", "")
        AlertDialog.Builder(this).setTitle(R.string.privacy_policy).setMessage(t).setCancelable(!backToConsent)
            .setPositiveButton(R.string.ok) { _, _ -> if (backToConsent) showConsent() }.show()
    }

    private fun autoClicker() {
        val svc = AutoClickAccessibilityService.instance
        if (svc == null) {
            AlertDialog.Builder(this).setMessage(R.string.acc_explain)
                .setPositiveButton(R.string.open_settings) { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }.setNegativeButton(R.string.cancel, null).show()
            return
        }
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("500"); hint = getString(R.string.interval_ms) }
        AlertDialog.Builder(this).setTitle(R.string.b_clicker).setMessage(R.string.interval_ms).setView(et)
            .setPositiveButton(R.string.start) { _, _ ->
                svc.startClicking(et.text.toString().toLongOrNull() ?: 500); toast(R.string.clicker_on)
            }
            .setNegativeButton(R.string.stop) { _, _ -> svc.stopClicking(); toast(R.string.clicker_off) }
            .show()
    }

    private fun startCapture(prompt: String) {
        capturePrompt = prompt
        projection.launch(capture.createIntent())   // Android shows its own "start recording" consent dialog
    }

    private fun toggleGameMode(on: Boolean) {
        if (!on) { GameMode.off(this); toast(R.string.mode_off); return }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) else GameMode.on(this)
        toast(R.string.mode_on)
    }

    private fun onCommand(text: String) {
        out.text = "🗣️ $text"
        when (voice.handle(text)) {
            VoiceCommandManager.Cmd.GAME_MODE_ON -> toggleGameMode(true)
            VoiceCommandManager.Cmd.GAME_MODE_OFF -> toggleGameMode(false)
            VoiceCommandManager.Cmd.UNKNOWN -> toast(R.string.cmd_unknown)
            VoiceCommandManager.Cmd.OPEN_SELF -> {}
        }
    }

    private fun settings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 16, 40, 0) }
        val key = EditText(this).apply {
            hint = getString(R.string.api_key); setText(Prefs.apiKey(context))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { hint = getString(R.string.model); setText(Prefs.model(context)) }
        val low = CheckBox(this).apply { text = getString(R.string.low_end); isChecked = Prefs.lowEnd(context) }
        box.addView(key); box.addView(model); box.addView(low)
        box.addView(Button(this).apply { text = getString(R.string.privacy_policy); setOnClickListener { showPolicy() } })
        AlertDialog.Builder(this).setTitle(R.string.b_settings).setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                Prefs.save(this, key.text.toString(), model.text.toString(), low.isChecked)
            }.setNegativeButton(R.string.cancel, null).show()
    }
}
