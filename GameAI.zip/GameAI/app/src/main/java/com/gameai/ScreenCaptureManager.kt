package com.gameai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.ByteArrayOutputStream

/** User-controlled, single-shot capture: permission dialog -> 3s delay -> one JPEG in memory -> stop. */
class ScreenCaptureManager(private val ctx: Context) {

    fun createIntent(): Intent =
        (ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent()

    fun start(resultCode: Int, data: Intent, onFrame: (ByteArray) -> Unit) {
        ScreenCaptureService.onFrame = onFrame
        val i = Intent(ctx, ScreenCaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
        ctx.startForegroundService(i)
    }
}

class ScreenCaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("capture", "Screen Help", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "capture")
            .setSmallIcon(R.drawable.ic_launcher).setContentTitle(getString(R.string.notif_capture)).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(2, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION") val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        main.postDelayed({ capture(code, data) }, 3000)
        return START_NOT_STICKY
    }

    private fun capture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {}, main)
            val scale = if (Prefs.lowEnd(this)) 0.4f else 0.6f
            val dm = resources.displayMetrics
            val w = (dm.widthPixels * scale).toInt(); val h = (dm.heightPixels * scale).toInt()
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            val vd = mp.createVirtualDisplay("gameai", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, main)
            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                r.setOnImageAvailableListener(null, null)
                try {
                    val p = img.planes[0]
                    val rowPx = p.rowStride / p.pixelStride
                    val full = Bitmap.createBitmap(rowPx, h, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(p.buffer)
                    val bmp = Bitmap.createBitmap(full, 0, 0, w, h)
                    val out = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, if (Prefs.lowEnd(this)) 50 else 70, out)
                    onFrame?.invoke(out.toByteArray())   // kept in memory only, never saved to storage
                } finally {
                    img.close(); vd.release(); reader.close(); stopSelf()
                }
            }, main)
        } catch (e: Exception) { stopSelf() }
    }

    override fun onDestroy() { projection?.stop(); onFrame = null; super.onDestroy() }

    companion object { @Volatile var onFrame: ((ByteArray) -> Unit)? = null }
}
