package com.gameai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Handles notification buttons so they work inside any game without opening GameAI. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            "play_voice" -> if (!VoiceChanger.playLast()) toast(c, R.string.no_rec)
            "toggle_click" -> {
                val s = AutoClickAccessibilityService.instance
                if (s == null) toast(c, R.string.need_acc)
                else if (s.isClicking) s.stopClicking()
                else s.startClicking(AutoClickAccessibilityService.lastInterval)
            }
        }
    }
    private fun toast(c: Context, r: Int) = Toast.makeText(c, r, Toast.LENGTH_SHORT).show()
}
