package com.gameai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Taps the screen centre at a fixed interval, only while the user has pressed Start. */
class AutoClickAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var intervalMs = 500L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val m = resources.displayMetrics
            val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels / 2f) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build()
            dispatchGesture(g, null, null)
            handler.postDelayed(this, intervalMs)
        }
    }

    fun startClicking(interval: Long) {
        intervalMs = interval.coerceAtLeast(50)
        lastInterval = intervalMs
        if (running) return
        running = true
        handler.post(tick)
    }

    fun stopClicking() { running = false; handler.removeCallbacks(tick) }
    val isClicking get() = running

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() = stopClicking()
    override fun onDestroy() { stopClicking(); instance = null; super.onDestroy() }

    companion object { @Volatile var instance: AutoClickAccessibilityService? = null
        @Volatile var lastInterval = 500L }
}
