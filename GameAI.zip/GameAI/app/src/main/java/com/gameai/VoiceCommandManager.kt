package com.gameai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.speech.RecognizerIntent

class VoiceCommandManager(private val context: Context) {

    fun createVoiceIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
    }

    enum class Cmd { GAME_MODE_ON, GAME_MODE_OFF, OPEN_SELF, UNKNOWN }

    /** Handles launch-type commands itself; returns a Cmd for the ones MainActivity must handle. */
    fun handle(raw: String): Cmd {
        val t = raw.lowercase()
        return when {
            "roblox" in t || "रोब्लॉक्स" in t -> {
                val i = context.packageManager.getLaunchIntentForPackage("com.roblox.client")
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); Cmd.OPEN_SELF }
                else Cmd.UNKNOWN
            }
            "music" in t || "म्यूजिक" in t || "गाना" in t -> {
                start(Intent(MediaStore.INTENT_ACTION_MUSIC_PLAYER)); Cmd.OPEN_SELF
            }
            "video" in t || "वीडियो" in t -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))); Cmd.OPEN_SELF
            }
            ("game mode" in t || "गेम मोड" in t) && ("off" in t || "बंद" in t) -> Cmd.GAME_MODE_OFF
            "game mode" in t || "गेम मोड" in t -> Cmd.GAME_MODE_ON
            "gameai" in t || "गेम ai" in t -> Cmd.OPEN_SELF
            else -> Cmd.UNKNOWN
        }
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }
}
