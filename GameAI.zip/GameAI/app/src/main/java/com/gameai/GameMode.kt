package com.gameai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Notification with quick actions (works over any game, no "display over other apps" permission). */
object GameMode {
    private const val CH = "gamemode"

    fun on(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Game Mode", NotificationManager.IMPORTANCE_LOW))
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun bc(code: Int, act: String) = PendingIntent.getBroadcast(c, code,
            Intent(c, ActionReceiver::class.java).setAction(act), fl)
        val open = PendingIntent.getActivity(c, 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), fl)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_launcher).setContentTitle(c.getString(R.string.notif_title))
            .setOngoing(true).setContentIntent(open)
            .addAction(0, c.getString(R.string.notif_play), bc(1, "play_voice"))
            .addAction(0, c.getString(R.string.notif_click), bc(2, "toggle_click"))
            .addAction(0, c.getString(R.string.notif_open), open)
            .build()
        nm.notify(1, n)
    }

    fun off(c: Context) = c.getSystemService(NotificationManager::class.java).cancel(1)
}
